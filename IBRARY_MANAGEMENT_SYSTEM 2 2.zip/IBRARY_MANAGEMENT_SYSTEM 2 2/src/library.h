#ifndef LIBRARY_H
#define LIBRARY_H

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

// Book Class
class Book {
private:
    int id;
    string title;
    string author;
    bool isIssued;
    
public:
    Book();
    Book(int i, string t, string a);
    
    // Getters
    int getId();
    string getTitle();
    string getAuthor();
    bool getStatus();
    
    // Setters
    void setId(int i);
    void setTitle(string t);
    void setAuthor(string a);
    void issueBook();
    void returnBook();
    
    // Display
    void show();
    
    // File operations
    void saveToFile(ofstream &file);
    void loadFromFile(ifstream &file);
};

// Library Class
class Library {
private:
    Book books[100];
    int totalBooks;
    string filename;
    
public:
    Library();
    ~Library();
    
    // Book operations
    void addBook();
    void showAllBooks();
    void searchBook();
    void deleteBook();
    void issueBook();
    void returnBook();
    void exportReport();
    
    // Helper methods
    Book* findBookById(int id);
    Book* findBookByTitle(string title);
    
    // File operations
    void loadFromFile();
    void saveToFile();
};

// User Base Class
class User {
protected:
    string username;
    string password;
    string role;
    
public:
    User();
    User(string u, string p, string r);
    virtual ~User();
    
    virtual void menu() = 0;  // Pure virtual function
    string getRole();
    bool checkLogin(string u, string p);
};

// Admin Class
class Admin : public User {
private:
    Library* lib;
    
public:
    Admin(Library* l);
    void menu() override;
};

// Member Class
class Member : public User {
private:
    Library* lib;
    
public:
    Member(Library* l);
    void menu() override;
};

// UI Class for ASCII Art and Display
class UI {
public:
    static void clearScreen();
    static void pause();
    static void printLine(int length = 50, char ch = '=');
    static void printBox(string text);
    static void printCentered(string text, int width = 50);
    static void printHeader(string title);
    static void printMenu(string options[], int count);
    static void printLoginScreen();
    static void printMainScreen();
    static void printBookArt();
    static void printSuccess(string message);
    static void printError(string message);
    static int getChoice(int min, int max);
    static string getString(string prompt);
    static int getInt(string prompt);
    static void showBookDetails(Book* book);
    static void showLibraryStats(Library* lib);
};

#endif