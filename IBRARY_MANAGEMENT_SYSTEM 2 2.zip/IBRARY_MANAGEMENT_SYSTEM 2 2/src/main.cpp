#include "library.h"

// Function to display login screen
User* showLogin(string role, Library* lib) {
    UI::clearScreen();
    UI::printLoginScreen();
    
    cout << "\n";
    UI::printLine(40, '-');
    cout << "       " << role << " LOGIN\n";
    UI::printLine(40, '-');
    
    string username = UI::getString("👤 Username: ");
    string password = UI::getString("🔒 Password: ");
    
    if(role == "Admin") {
        if(username == "admin" && password == "admin123") {
            UI::printSuccess("Login successful! Welcome Admin!");
            UI::pause();
            return new Admin(lib);
        }
    } 
    else if(role == "Member") {
        if(username == "user" && password == "user123") {
            UI::printSuccess("Login successful! Welcome Member!");
            UI::pause();
            return new Member(lib);
        }
    }
    
    UI::printError("Invalid username or password!");
    UI::pause();
    return nullptr;
}

int main() {
    // Create library
    Library library;
    
    while(true) {
        UI::printMainScreen();
        
        cout << "     Please select an option:\n\n";
        
        string options[] = {
            "👨‍💼 Admin Login",
            "👤 Member Login", 
            "🚪 Exit System"
        };
        UI::printMenu(options, 3);
        
        int choice = UI::getChoice(1, 3);
        User* currentUser = nullptr;
        
        switch(choice) {
            case 1:  // Admin Login
                currentUser = showLogin("Admin", &library);
                if(currentUser != nullptr) {
                    currentUser->menu();
                    delete currentUser;
                }
                break;
                
            case 2:  // Member Login
                currentUser = showLogin("Member", &library);
                if(currentUser != nullptr) {
                    currentUser->menu();
                    delete currentUser;
                }
                break;
                
            case 3:  // Exit
                UI::clearScreen();
                cout << "\n";
                UI::printLine(50, '*');
                cout << "\n       🙏 THANK YOU FOR USING\n";
                cout << "     LIBRARY MANAGEMENT SYSTEM\n\n";
                cout << "          📚 Keep Reading! 📚\n";
                UI::printLine(50, '*');
                cout << "\n";
                return 0;
        }
    }
    
    return 0;
}