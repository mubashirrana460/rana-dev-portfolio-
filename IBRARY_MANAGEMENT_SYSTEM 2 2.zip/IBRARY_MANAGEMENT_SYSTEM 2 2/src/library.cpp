#include "library.h"
#include <limits>
#include <iomanip>

// ==================== UI CLASS ====================
void UI::clearScreen() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

void UI::pause() {
    cout << "\n📖 Press Enter to continue...";
    cin.ignore();
    cin.get();
}

void UI::printLine(int length, char ch) {
    for(int i = 0; i < length; i++) cout << ch;
    cout << endl;
}

void UI::printBox(string text) {
    printLine(50, '=');
    cout << "║" << setw(48) << left << (" " + text) << "║" << endl;
    printLine(50, '=');
}

void UI::printCentered(string text, int width) {
    int padding = (width - text.length()) / 2;
    cout << string(padding, ' ') << text << endl;
}

void UI::printHeader(string title) {
    clearScreen();
    cout << "\n";
    printLine(60, '*');
    printCentered("📚 LIBRARY MANAGEMENT SYSTEM 📚", 60);
    printCentered(title, 60);
    printLine(60, '*');
    cout << "\n";
}

void UI::printMenu(string options[], int count) {
    for(int i = 0; i < count; i++) {
        cout << "   " << (i+1) << ". " << options[i] << "\n";
    }
    cout << "\n";
    printLine(40, '-');
}

void UI::printLoginScreen() {
    clearScreen();
    cout << "\n";
    printLine(60, '*');
    
    cout << R"(
        ╔═══════════════════════════════════════╗
        ║        📚 WELCOME TO LIBRARY 📚       ║
        ║                                       ║
        ║         ___________________           ║
        ║        |                   |          ║
        ║        |    LIBRARY        |          ║
        ║        |    MANAGEMENT     |          ║
        ║        |    SYSTEM         |          ║
        ║        |___________________|          ║
        ║                                       ║
        ║      📖 Knowledge • Access • Share 📖 ║
        ╚═══════════════════════════════════════╝
    )" << endl;
    
    printLine(60, '*');
    cout << "\n";
}

void UI::printMainScreen() {
    clearScreen();
    cout << "\n";
    printLine(60, '*');
    
    cout << R"(
          ╔══════════════════════════════════════╗
          ║                                      ║
          ║         MAIN MENU                    ║
          ║                                      ║
          ║    ┌────────────────────┐            ║
          ║    │ 1. 👨‍💼 Admin Login  │            ║
          ║    │ 2. 👤 Member Login │            ║
          ║    │ 3. 🚪 Exit         │            ║
          ║    └────────────────────┘            ║
          ║                                      ║
          ╚══════════════════════════════════════╝
    )" << endl;
    
    printLine(60, '*');
    cout << "\n";
}

void UI::printBookArt() {
    cout << R"(
          ┌─────────────────────────────────────┐
          │                                     │
          │          📚 BOOK SHELF 📚            │
          │                                     │
          │    ┌────────┐ ┌────────┐            │
          │    │ Book 1 │ │ Book 2 │            │
          │    │ Title  │ │ Title  │            │
          │    │ Author │ │ Author │            │
          │    └────────┘ └────────┘            │
          │                                     │
          │    ┌────────┐ ┌────────┐            │
          │    │ Book 3 │ │ Book 4 │            │
          │    │ Title  │ │ Title  │            │
          │    │ Author │ │ Author │            │
          │    └────────┘ └────────┘            │
          │                                     │
          └─────────────────────────────────────┘
    )" << endl;
}

void UI::printSuccess(string message) {
    cout << "\n✅ " << message << "\n";
}

void UI::printError(string message) {
    cout << "\n❌ " << message << "\n";
}

int UI::getChoice(int min, int max) {
    int choice;
    while(true) {
        cout << "🔢 Enter your choice [" << min << "-" << max << "]: ";
        cin >> choice;
        
        if(cin.fail() || choice < min || choice > max) {
            cin.clear();
            cin.ignore(1000, '\n');
            printError("Invalid choice! Please try again.");
        } else {
            cin.ignore();
            return choice;
        }
    }
}

string UI::getString(string prompt) {
    string input;
    cout << prompt;
    getline(cin, input);
    return input;
}

int UI::getInt(string prompt) {
    int num;
    cout << prompt;
    cin >> num;
    cin.ignore();
    return num;
}

void UI::showBookDetails(Book* book) {
    if(book == nullptr) return;
    
    cout << "\n";
    printLine(40, '-');
    cout << "📘 BOOK DETAILS:\n";
    printLine(40, '-');
    book->show();
}

void UI::showLibraryStats(Library* lib) {
    cout << "\n";
    printLine(40, '-');
    cout << "📊 LIBRARY STATISTICS:\n";
    printLine(40, '-');
    // Statistics would be implemented in Library class
    cout << "📚 Total Books: (to be implemented)\n";
    cout << "📖 Available: (to be implemented)\n";
    cout << "📌 Issued: (to be implemented)\n";
    printLine(40, '-');
}

// ==================== BOOK CLASS ====================
Book::Book() : id(0), title(""), author(""), isIssued(false) {}

Book::Book(int i, string t, string a) : id(i), title(t), author(a), isIssued(false) {}

int Book::getId() { return id; }
string Book::getTitle() { return title; }
string Book::getAuthor() { return author; }
bool Book::getStatus() { return isIssued; }

void Book::setId(int i) { id = i; }
void Book::setTitle(string t) { title = t; }
void Book::setAuthor(string a) { author = a; }
void Book::issueBook() { isIssued = true; }
void Book::returnBook() { isIssued = false; }

void Book::show() {
    cout << "\n";
    cout << "┌─────────────────────────────────┐\n";
    cout << "│ 📖 Book ID:    " << setw(18) << left << id << "│\n";
    cout << "│ 📚 Title:      " << setw(18) << left << title.substr(0, 15) << "│\n";
    cout << "│ ✍️  Author:     " << setw(18) << left << author.substr(0, 15) << "│\n";
    cout << "│ 📍 Status:     " << setw(18) << left << (isIssued ? "📌 Issued" : " Available") << "│\n";
    cout << "└─────────────────────────────────┘\n";
}

void Book::saveToFile(ofstream &file) {
    file << id << endl;
    file << title << endl;
    file << author << endl;
    file << isIssued << endl;
}

void Book::loadFromFile(ifstream &file) {
    string temp;
    
    getline(file, temp);
    id = stoi(temp);
    
    getline(file, title);
    getline(file, author);
    
    getline(file, temp);
    isIssued = (temp == "1");
}

// ==================== LIBRARY CLASS ====================
Library::Library() : totalBooks(0), filename("library_data.txt") {
    loadFromFile();
}

Library::~Library() {
    saveToFile();
}

void Library::loadFromFile() {
    ifstream file(filename);
    if(!file.is_open()) {
        cout << "📝 Creating new library database...\n";
        return;
    }
    
    file >> totalBooks;
    file.ignore();
    
    for(int i = 0; i < totalBooks; i++) {
        books[i].loadFromFile(file);
    }
    
    file.close();
    UI::printSuccess("Loaded " + to_string(totalBooks) + " books from database.");
}

void Library::saveToFile() {
    ofstream file(filename);
    file << totalBooks << endl;
    
    for(int i = 0; i < totalBooks; i++) {
        books[i].saveToFile(file);
    }
    
    file.close();
}

Book* Library::findBookById(int id) {
    for(int i = 0; i < totalBooks; i++) {
        if(books[i].getId() == id) {
            return &books[i];
        }
    }
    return nullptr;
}

Book* Library::findBookByTitle(string title) {
    for(int i = 0; i < totalBooks; i++) {
        if(books[i].getTitle() == title) {
            return &books[i];
        }
    }
    return nullptr;
}

void Library::addBook() {
    UI::printHeader("ADD NEW BOOK 📖");
    
    if(totalBooks >= 100) {
        UI::printError("Library is full! Cannot add more books.");
        return;
    }
    
    string title = UI::getString("📖 Enter book title: ");
    string author = UI::getString("✍️  Enter book author: ");
    
    int id = totalBooks + 1;
    books[totalBooks] = Book(id, title, author);
    totalBooks++;
    
    UI::printSuccess("Book added successfully with ID: " + to_string(id));
    saveToFile();
}

void Library::showAllBooks() {
    UI::printHeader("ALL BOOKS 📚");
    
    if(totalBooks == 0) {
        UI::printError("No books in the library!");
        return;
    }
    
    cout << "\n";
    cout << "┌────┬───────────────────────┬───────────────────────┬──────────────┐\n";
    cout << "│ ID │ Title                 │ Author                │ Status       │\n";
    cout << "├────┼───────────────────────┼───────────────────────┼──────────────┤\n";
    
    for(int i = 0; i < totalBooks; i++) {
        cout << "│ " << setw(2) << left << books[i].getId() << " │ ";
        cout << setw(21) << left << (books[i].getTitle().length() > 20 ? 
              books[i].getTitle().substr(0, 18) + ".." : books[i].getTitle()) << " │ ";
        cout << setw(21) << left << (books[i].getAuthor().length() > 20 ? 
              books[i].getAuthor().substr(0, 18) + ".." : books[i].getAuthor()) << " │ ";
        cout << setw(12) << left << (books[i].getStatus() ? " Issued" : " Available") << " │\n";
    }
    
    cout << "└────┴───────────────────────┴───────────────────────┴──────────────┘\n";
    cout << "\n📊 Total Books: " << totalBooks << endl;
}

void Library::searchBook() {
    UI::printHeader("SEARCH BOOK 🔍");
    
    if(totalBooks == 0) {
        UI::printError("No books in the library!");
        return;
    }
    
    string options[] = {"Search by ID", "Search by Title", "Go Back"};
    UI::printMenu(options, 3);
    
    int choice = UI::getChoice(1, 3);
    
    if(choice == 1) {
        int id = UI::getInt("🔢 Enter book ID: ");
        Book* book = findBookById(id);
        
        if(book != nullptr) {
            UI::showBookDetails(book);
        } else {
            UI::printError("Book not found!");
        }
    } 
    else if(choice == 2) {
        string title = UI::getString("📖 Enter book title: ");
        Book* book = findBookByTitle(title);
        
        if(book != nullptr) {
            UI::showBookDetails(book);
        } else {
            UI::printError("Book not found!");
        }
    }
}

void Library::deleteBook() {
    UI::printHeader("DELETE BOOK 🗑️");
    showAllBooks();
    
    if(totalBooks == 0) return;
    
    int id = UI::getInt("\n🔢 Enter book ID to delete: ");
    Book* book = findBookById(id);
    
    if(book == nullptr) {
        UI::printError("Book not found!");
        return;
    }
    
    // Simple deletion by shifting
    int index = -1;
    for(int i = 0; i < totalBooks; i++) {
        if(books[i].getId() == id) {
            index = i;
            break;
        }
    }
    
    if(index != -1) {
        // Shift all books after index
        for(int i = index; i < totalBooks - 1; i++) {
            books[i] = books[i + 1];
            books[i].setId(i + 1);  // Update IDs
        }
        totalBooks--;
        
        // Update remaining IDs
        for(int i = index; i < totalBooks; i++) {
            books[i].setId(i + 1);
        }
        
        UI::printSuccess("Book deleted successfully!");
        saveToFile();
    }
}

void Library::issueBook() {
    UI::printHeader("BORROW BOOK 📌");
    showAllBooks();
    
    if(totalBooks == 0) return;
    
    int id = UI::getInt("\n🔢 Enter book ID to borrow: ");
    Book* book = findBookById(id);
    
    if(book == nullptr) {
        UI::printError("Book not found!");
        return;
    }
    
    if(book->getStatus()) {
        UI::printError("Book is already issued!");
    } else {
        book->issueBook();
        UI::printSuccess("Book issued successfully!");
        saveToFile();
    }
}

void Library::returnBook() {
    UI::printHeader("RETURN BOOK 📥");
    
    if(totalBooks == 0) {
        UI::printError("No books in the library!");
        return;
    }
    
    int id = UI::getInt("🔢 Enter book ID to return: ");
    Book* book = findBookById(id);
    
    if(book == nullptr) {
        UI::printError("Book not found!");
        return;
    }
    
    if(!book->getStatus()) {
        UI::printError("Book was not issued!");
    } else {
        book->returnBook();
        UI::printSuccess("Book returned successfully!");
        saveToFile();
    }
}

void Library::exportReport() {
    UI::printHeader("EXPORT REPORT 📄");
    
    ofstream file("library_report.txt");
    
    file << "========================================\n";
    file << "        LIBRARY MANAGEMENT REPORT       \n";
    file << "========================================\n\n";
    file << "Report Generated on: [Date]\n\n";
    file << "Total Books: " << totalBooks << "\n\n";
    file << "BOOK LIST:\n";
    file << "----------\n";
    
    for(int i = 0; i < totalBooks; i++) {
        file << "Book ID: " << books[i].getId() << "\n";
        file << "Title: " << books[i].getTitle() << "\n";
        file << "Author: " << books[i].getAuthor() << "\n";
        file << "Status: " << (books[i].getStatus() ? "Issued" : "Available") << "\n";
        file << "-------------------\n";
    }
    
    file.close();
    UI::printSuccess("Report exported to 'library_report.txt'");
}

// ==================== USER CLASS ====================
User::User() : username(""), password(""), role("") {}
User::User(string u, string p, string r) : username(u), password(p), role(r) {}
User::~User() {}

string User::getRole() { return role; }
bool User::checkLogin(string u, string p) {
    return (username == u && password == p);
}

// ==================== ADMIN CLASS ====================
Admin::Admin(Library* l) : User("admin", "admin123", "Admin"), lib(l) {}

void Admin::menu() {
    while(true) {
        UI::printHeader("ADMIN DASHBOARD 👨‍💼");
        
        cout << "     ╔══════════════════════════════╗\n";
        cout << "     ║       ADMIN MENU             ║\n";
        cout << "     ╠══════════════════════════════╣\n";
        cout << "     ║  1. 📖 Add New Book          ║\n";
        cout << "     ║  2. 📚 View All Books        ║\n";
        cout << "     ║  3. 🔍 Search Book           ║\n";
        cout << "     ║  4. 🗑️  Delete Book          ║\n";
        cout << "     ║  5. 📌 Borrow Book           ║\n";
        cout << "     ║  6. 📥 Return Book           ║\n";
        cout << "     ║  7. 📄 Export Report         ║\n";
        cout << "     ║  8. 🚪 Logout                ║\n";
        cout << "     ╚══════════════════════════════╝\n\n";
        
        int choice = UI::getChoice(1, 8);
        
        switch(choice) {
            case 1: lib->addBook(); break;
            case 2: lib->showAllBooks(); break;
            case 3: lib->searchBook(); break;
            case 4: lib->deleteBook(); break;
            case 5: lib->issueBook(); break;
            case 6: lib->returnBook(); break;
            case 7: lib->exportReport(); break;
            case 8: 
                UI::printSuccess("Logged out successfully!");
                return;
        }
        UI::pause();
    }
}

// ==================== MEMBER CLASS ====================
Member::Member(Library* l) : User("user", "user123", "Member"), lib(l) {}

void Member::menu() {
    while(true) {
        UI::printHeader("MEMBER DASHBOARD 👤");
        
        cout << "     ╔══════════════════════════════╗\n";
        cout << "     ║       MEMBER MENU            ║\n";
        cout << "     ╠══════════════════════════════╣\n";
        cout << "     ║  1. 📚 View All Books        ║\n";
        cout << "     ║  2. 🔍 Search Book           ║\n";
        cout << "     ║  3. 📌 Borrow Book           ║\n";
        cout << "     ║  4. 📥 Return Book           ║\n";
        cout << "     ║  5. 🚪 Logout                ║\n";
        cout << "     ╚══════════════════════════════╝\n\n";
        
        int choice = UI::getChoice(1, 5);
        
        switch(choice) {
            case 1: lib->showAllBooks(); break;
            case 2: lib->searchBook(); break;
            case 3: lib->issueBook(); break;
            case 4: lib->returnBook(); break;
            case 5: 
                UI::printSuccess("Logged out successfully!");
                return;
        }
        UI::pause();
    }
}